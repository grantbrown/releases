library(testthat)
library(ABSEIR)

test_check("ABSEIR")
