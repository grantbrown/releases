Ifelse = function(x, a, b)
{
    if (x){
        return(a)
    }
    b
}
