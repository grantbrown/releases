#ifndef ABSEIR_STRING_CONST_HDR
#define ABSEIR_STRING_CONST_HDR

static const std::string sim_atom = "sim";
static const std::string sim_result_atom = "sim_rslt";

#endif
